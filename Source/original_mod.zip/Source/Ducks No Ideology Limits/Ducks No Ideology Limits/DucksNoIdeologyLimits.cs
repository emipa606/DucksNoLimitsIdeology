﻿using HarmonyLib;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using System.Reflection;
using Verse;
using Verse.AI;
using UnityEngine;
using System;
using System.Reflection.Emit;

namespace DucksNoIdeologyLimits
{
    public class DucksNoIdeologyLimitsMod : Mod
    {
        public static DucksNoIdeologyLimitsSettings settings;
        public int maxCountFix = 100;

        public DucksNoIdeologyLimitsMod(ModContentPack content) : base(content)
        {
            DucksNoIdeologyLimitsMod.settings = GetSettings<DucksNoIdeologyLimitsSettings>();
            var harmony = new Harmony("net.ducks.rimworld.mod.ducksnoideologylimits");
            harmony.PatchAll();
        }
        //public override string SettingsCategory() => "Ducks' No Ideology Limits";
        //public override void DoSettingsWindowContents(Rect canvas) { settings.DoWindowContents(canvas); }
    }

    [HarmonyPatch(typeof(IdeoFoundation))]
    [HarmonyPatch("CanAdd")]
    public class DucksNoIdeologyLimits_CanAdd
    {
        public static bool Prefix(ref AcceptanceReport __result, IdeoFoundation __instance, ref PreceptDef precept, ref bool checkDuplicates)
        {
            List<Precept> preceptsListForReading = __instance.ideo.PreceptsListForReading;
            if (precept.takeNameFrom != null)
            {
                bool flag = false;
                using (List<Precept>.Enumerator enumerator = __instance.ideo.PreceptsListForReading.GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        if (enumerator.Current.def == precept.takeNameFrom)
                        {
                            flag = true;
                            break;
                        }
                    }
                }
                if (!flag)
                {
                    __result = false;
                    return false;
                }
            }
            for (int j = 0; j < preceptsListForReading.Count; j++)
            {
                if (checkDuplicates)
                {
                    if (precept == preceptsListForReading[j].def)
                    {
                        if (!precept.allowDuplicates)
                        {
                            __result = false;
                            return false;
                        }
                    }
                    else if (!precept.issue.allowMultiplePrecepts && precept.issue == preceptsListForReading[j].def.issue)
                    {
                        __result = false;
                        return false;
                    }
                }
            }
            __result = true;
            return false;
        }
    }

    [HarmonyPatch(typeof(IdeoUIUtility))]
    [HarmonyPatch("CanAddRitualPattern")]
    public class DucksNoIdeologyLimits_CanAddRitualPattern
    {
        public static bool Prefix(ref bool __result)
        {
            __result = true;
            return false;
        }
    }

    [HarmonyPatch(typeof(IdeoFoundation))]
    [HarmonyPatch("InitPrecepts")]
    public class DucksNoIdeologyLimits_InitPrecepts
    {
        //public static void Prefix(ref IntRange ___MemeCountRangeAbsolute, ref int ___MaxStyleCategories, ref int ___MaxRituals, ref int ___MaxMultiRoles)
        public static void Prefix(ref IntRange ___MemeCountRangeAbsolute)
        {
            ___MemeCountRangeAbsolute = new IntRange(0, 1000);
            //___MaxStyleCategories = 1000;
            //___MaxRituals = 1000;
            //___MaxMultiRoles = 1000;
        }
    }

    [HarmonyPatch(typeof(IdeoUIUtility))]
    [HarmonyPatch("DoPreceptsInt")]
    public static class DucksNoIdeologyLimits_UIPatch
    {
        private static FieldInfo maxCountField = AccessTools.Field(typeof(PreceptDef), nameof(PreceptDef.maxCount));
        //private static FieldInfo maxCountFixField = AccessTools.Field(typeof(DucksNoIdeologyLimitsMod), nameof(DucksNoIdeologyLimitsMod.maxCountFix));
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            Log.Message("DUCKS NO IDEOLOGY LIMITS UI PATCH = START");

            int patches = 0;

            var codes = new List<CodeInstruction>(instructions);
            for (int j = 0; j < codes.Count; j++)
            {
                if (codes[j].opcode == OpCodes.Ldfld && codes[j].operand == maxCountField)
                {
                    Log.Message("DUCKS NO IDEOLOGY LIMITS UI PATCH = MAX PRECEPT COUNT = FOUND + PATCHED " + j);
                    codes[j].opcode = OpCodes.Ldc_I4;
                    codes[j].operand = 100;
                    patches++;
                }
                else if (codes[j].opcode == OpCodes.Ldstr && codes[j].operand == "MaxRitualCount")
                {
                    Log.Message("DUCKS NO IDEOLOGY LIMITS UI PATCH = MAX RITUAL = FOUND STRING " + j);
                    for (int i = j; i > j-30; i--)
                    {
                        if (codes[i].opcode == OpCodes.Brfalse_S)
                        {
                            Log.Message("DUCKS NO IDEOLOGY LIMITS UI PATCH = MAX RITUAL = PATCHED " + i);
                            codes[i - 1].opcode = OpCodes.Nop;
                            codes[i].opcode = OpCodes.Br_S;
                            patches++;
                            break;
                        }
                    }
                }
                if (patches >= 2)
                {
                    break;
                }
            }

            return codes.AsEnumerable();
        }
    }

}

        