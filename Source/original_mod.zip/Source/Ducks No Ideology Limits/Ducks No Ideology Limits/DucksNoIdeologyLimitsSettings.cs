﻿using System.Collections.Generic;
using Verse;
using UnityEngine;

namespace DucksNoIdeologyLimits
{
    public class DucksNoIdeologyLimitsSettings : ModSettings
    {
        public int MaxLevel = 0;

        public bool PatchSkillCap = true;
        public int ValueSkillCap = 2000;

        public bool MuteCraftNotifications = true;

        public void DoWindowContents(Rect canvas)
        {
            Listing_Standard listing_Standard = new Listing_Standard();
            listing_Standard.ColumnWidth = 250f;
            listing_Standard.Begin(canvas);
            listing_Standard.End();
        }

        public override void ExposeData()
        {
            base.ExposeData();
        }
    }
}